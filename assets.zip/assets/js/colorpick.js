$('#colorpicker-holder').ColorPicker({flat:true});
