$('#container-banners a').click(function() {
    $(this).attr('target', '_blank');
});